import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Tvashta Interior — Premium Interior Design, Bangalore",
  description: "Premium interior design solutions for apartments, villas & commercial spaces across Bangalore. Modular kitchens, luxury bedrooms, false ceilings and more.",
  robots: "noindex, nofollow",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <meta name="robots" content="noindex, nofollow" />
        <link rel="icon" href="/logo.png" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,500;0,600;0,700;1,400;1,600&family=Inter:wght@300;400;500;600&family=Cormorant+Garamond:ital,wght@0,300;0,400;1,300;1,400&display=swap"
          rel="stylesheet"
        />
      </head>
      <body style={{ background: "#0D0D0D" }}>
        {children}
      </body>
    </html>
  );
}
