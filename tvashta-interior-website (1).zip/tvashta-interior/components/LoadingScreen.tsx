"use client";
import { useEffect, useState } from "react";
import Image from "next/image";

export default function LoadingScreen() {
  const [done, setDone] = useState(false);
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((p) => {
        if (p >= 100) {
          clearInterval(interval);
          setTimeout(() => setDone(true), 300);
          return 100;
        }
        return p + Math.random() * 15;
      });
    }, 80);
    return () => clearInterval(interval);
  }, []);

  if (done) return null;

  return (
    <div
      className="loading-screen transition-opacity duration-500"
      style={{ opacity: progress >= 100 ? 0 : 1, pointerEvents: progress >= 100 ? "none" : "all" }}
    >
      <div className="relative w-48 h-20 mb-10">
        <Image src="/logo.png" alt="Tvashta Interior" fill className="object-contain" style={{ pointerEvents: "none" }} />
      </div>

      <div className="w-48 h-px bg-white/10 relative overflow-hidden mb-4">
        <div
          className="absolute inset-y-0 left-0 bg-gold transition-all duration-150"
          style={{ width: `${Math.min(progress, 100)}%` }}
        />
      </div>

      <p className="text-cream/30 text-xs tracking-[0.3em] uppercase">Crafting your experience…</p>
    </div>
  );
}
