"use client";
import { useEffect, useRef } from "react";
import { CheckCircle2, Award, Users, Zap, Shield } from "lucide-react";

const features = [
  { icon: CheckCircle2, label: "End-to-End Solutions" },
  { icon: Shield, label: "Transparent Pricing" },
  { icon: Award, label: "Premium Materials" },
  { icon: Users, label: "Dedicated Project Management" },
  { icon: Zap, label: "On-Time Delivery" },
];

export default function About() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.querySelectorAll(".reveal").forEach((el, i) => {
              setTimeout(() => el.classList.add("visible"), i * 120);
            });
          }
        });
      },
      { threshold: 0.15 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="about" ref={sectionRef} className="py-28 bg-[#0D0D0D]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Image grid */}
          <div className="relative">
            <div className="grid grid-cols-2 gap-3">
              <div className="reveal space-y-3">
                <div className="overflow-hidden aspect-[4/3]">
                  <img
                    src="https://images.unsplash.com/photo-1600121848594-d8644e57abab?w=600&q=80"
                    alt="Interior"
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                    style={{ pointerEvents: "none" }}
                  />
                </div>
                <div className="overflow-hidden aspect-square">
                  <img
                    src="https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?w=600&q=80"
                    alt="Interior"
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                    style={{ pointerEvents: "none" }}
                  />
                </div>
              </div>
              <div className="reveal space-y-3 mt-8">
                <div className="overflow-hidden aspect-square">
                  <img
                    src="https://images.unsplash.com/photo-1616486338812-3dadae4b4ace?w=600&q=80"
                    alt="Interior"
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                    style={{ pointerEvents: "none" }}
                  />
                </div>
                <div className="overflow-hidden aspect-[4/3]">
                  <img
                    src="https://images.unsplash.com/photo-1615529328331-f8917597711f?w=600&q=80"
                    alt="Interior"
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                    style={{ pointerEvents: "none" }}
                  />
                </div>
              </div>
            </div>
            {/* Floating badge */}
            <div className="reveal absolute -bottom-6 left-1/2 -translate-x-1/2 glass-card px-8 py-4 text-center whitespace-nowrap">
              <p className="gold-text text-2xl font-bold" style={{ fontFamily: "var(--font-playfair)" }}>5+ Years</p>
              <p className="text-cream/50 text-xs tracking-widest uppercase">Of Excellence</p>
            </div>
          </div>

          {/* Content */}
          <div className="lg:pl-8">
            <div className="reveal luxury-divider mb-6">
              <span className="text-gold text-xs tracking-[0.3em] uppercase font-medium">Our Story</span>
            </div>

            <h2
              className="reveal text-4xl md:text-5xl font-bold text-white mb-6 leading-tight"
              style={{ fontFamily: "var(--font-playfair)" }}
            >
              About{" "}
              <span className="gold-text italic">Tvashta Interior</span>
            </h2>

            <p className="reveal text-cream/60 text-lg leading-relaxed mb-4">
              Tvashta Interior specializes in premium residential and commercial interior solutions. We combine creativity, functionality, and craftsmanship to deliver exceptional living experiences.
            </p>
            <p className="reveal text-cream/50 leading-relaxed mb-10">
              From modular kitchens to luxury bedrooms, from false ceilings to bespoke TV units — every space we touch becomes a reflection of its owner's personality, elevated by our design expertise and commitment to quality.
            </p>

            <div className="reveal grid grid-cols-1 gap-3 mb-10">
              {features.map((f) => (
                <div key={f.label} className="flex items-center gap-3">
                  <f.icon size={18} className="text-gold flex-shrink-0" />
                  <span className="text-cream/80 text-sm font-medium">{f.label}</span>
                </div>
              ))}
            </div>

            <button
              onClick={() => document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" })}
              className="allow-pointer reveal bg-gold text-charcoal px-8 py-4 text-sm font-bold tracking-widest uppercase hover:bg-gold-light transition-colors"
            >
              Start Your Project
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
