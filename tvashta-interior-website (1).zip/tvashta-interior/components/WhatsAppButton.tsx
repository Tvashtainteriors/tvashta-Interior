"use client";
import { useState } from "react";
import { MessageCircle, X } from "lucide-react";

export default function WhatsAppButton() {
  const [showTip, setShowTip] = useState(true);

  return (
    <div className="fixed bottom-7 right-7 z-50 flex flex-col items-end gap-2">
      {showTip && (
        <div className="bg-white text-gray-800 text-sm px-4 py-2 rounded shadow-xl flex items-center gap-3 mr-1">
          <span>Chat with us on WhatsApp!</span>
          <button className="allow-pointer text-gray-400 hover:text-gray-600" onClick={() => setShowTip(false)}>
            <X size={14} />
          </button>
        </div>
      )}
      <a
        href="https://wa.me/919876543210?text=Hi Tvashta! I'm interested in your interior design services."
        target="_blank"
        rel="noreferrer"
        className="whatsapp-btn allow-pointer"
        aria-label="Chat on WhatsApp"
        onClick={() => setShowTip(false)}
      >
        <svg viewBox="0 0 24 24" width="28" height="28" fill="white">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
          <path d="M12 0C5.373 0 0 5.373 0 12c0 2.125.554 4.118 1.523 5.85L.057 23.98l6.304-1.653A11.942 11.942 0 0012 24c6.627 0 12-5.373 12-12S18.627 0 12 0zm0 21.818a9.806 9.806 0 01-5.003-1.371l-.36-.213-3.714.974.992-3.622-.234-.374A9.787 9.787 0 012.182 12C2.182 6.58 6.58 2.182 12 2.182S21.818 6.58 21.818 12 17.42 21.818 12 21.818z"/>
        </svg>
      </a>
    </div>
  );
}
