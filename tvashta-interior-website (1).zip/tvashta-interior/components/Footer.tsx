"use client";
import Image from "next/image";
import { Phone, Mail, MapPin, MessageCircle, PlayCircle, Share2, Users } from "lucide-react";

const services = [
  "Bedroom Designs", "Modular Kitchens", "False Ceiling", "TV Unit Designs",
  "Dresser Units", "Staircase Walls", "Bed Back Designs", "Commercial Interiors",
];

export default function Footer() {
  return (
    <footer className="bg-[#080808] border-t border-gold/10">
      <div className="max-w-7xl mx-auto px-6 pt-16 pb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="relative w-36 h-14 mb-6">
              <Image src="/logo.png" alt="Tvashta Interior" fill className="object-contain" style={{ pointerEvents: "none" }} />
            </div>
            <p className="text-cream/40 text-sm leading-relaxed mb-6">
              Transforming spaces into timeless experiences. Premium interior design solutions across Bangalore.
            </p>
            <div className="flex gap-3">
              {[
                { icon: Share2, href: "#", label: "Instagram" },
                { icon: Users, href: "#", label: "Facebook" },
                { icon: PlayCircle, href: "#", label: "Youtube" },
                { icon: MessageCircle, href: "https://wa.me/919876543210", label: "WhatsApp" },
              ].map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  target="_blank"
                  rel="noreferrer"
                  aria-label={s.label}
                  className="allow-pointer w-9 h-9 border border-gold/20 text-gold/50 hover:border-gold hover:text-gold flex items-center justify-center transition-colors"
                >
                  <s.icon size={15} />
                </a>
              ))}
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-gold text-xs tracking-[0.25em] uppercase font-semibold mb-5">Our Services</h4>
            <ul className="space-y-2">
              {services.map((s) => (
                <li key={s}>
                  <span className="text-cream/40 text-sm hover:text-gold/60 transition-colors cursor-default">{s}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-gold text-xs tracking-[0.25em] uppercase font-semibold mb-5">Quick Links</h4>
            <ul className="space-y-2">
              {[
                ["About Us", "#about"],
                ["Portfolio", "#portfolio"],
                ["The Tvashta Difference", "#difference"],
                ["How It Works", "#process"],
                ["Testimonials", "#testimonials"],
                ["Contact", "#contact"],
              ].map(([label, href]) => (
                <li key={label}>
                  <a
                    href={href}
                    className="allow-pointer text-cream/40 text-sm hover:text-gold/60 transition-colors"
                    onClick={(e) => {
                      e.preventDefault();
                      document.querySelector(href)?.scrollIntoView({ behavior: "smooth" });
                    }}
                  >
                    {label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-gold text-xs tracking-[0.25em] uppercase font-semibold mb-5">Contact Us</h4>
            <div className="space-y-4">
              {[
                { icon: Phone, text: "+91 98765 43210", href: "tel:+919876543210" },
                { icon: Mail, text: "hello@tvashta.in", href: "mailto:hello@tvashta.in" },
                { icon: MapPin, text: "Indiranagar, Bangalore — 560038", href: "#" },
              ].map((c) => (
                <a key={c.text} href={c.href} className="allow-pointer flex items-start gap-3 text-cream/40 hover:text-cream/70 transition-colors">
                  <c.icon size={14} className="text-gold mt-0.5 flex-shrink-0" />
                  <span className="text-sm">{c.text}</span>
                </a>
              ))}
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-gold/10 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-cream/25 text-xs">
            © {new Date().getFullYear()} Tvashta Interior. All rights reserved. Bangalore, India.
          </p>
          <p className="text-cream/15 text-xs">
            Designed with ♥ for beautiful spaces
          </p>
        </div>
      </div>
    </footer>
  );
}
