"use client";
import { useEffect, useRef } from "react";
import { MessageSquare, Pencil, CheckSquare, Hammer, Sparkles, Home } from "lucide-react";

const steps = [
  { icon: MessageSquare, num: "01", title: "Meet a Designer", desc: "We begin with a detailed consultation to understand your lifestyle, preferences, and space requirements." },
  { icon: Pencil, num: "02", title: "Initial Design Advance", desc: "Our designers create concept boards, material palettes, and 3D visualizations of your future space." },
  { icon: CheckSquare, num: "03", title: "Design Approval", desc: "You review and approve the final designs, layouts, and material selections before work begins." },
  { icon: Hammer, num: "04", title: "Execution Begins", desc: "Our skilled craftsmen and project managers ensure quality execution with regular progress updates." },
  { icon: Sparkles, num: "05", title: "Final Installations", desc: "Premium fixtures, furniture, and décor elements are installed with precision and care." },
  { icon: Home, num: "06", title: "Move In & Enjoy", desc: "Handover of your transformed space with a walkthrough and documentation of all warranties." },
];

export default function Process() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          e.target.querySelectorAll(".reveal").forEach((el, i) => {
            setTimeout(() => el.classList.add("visible"), i * 120);
          });
        }
      },
      { threshold: 0.1 }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);

  return (
    <section id="process" ref={ref} className="py-28 bg-[#111111]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-20 reveal">
          <div className="luxury-divider justify-center mb-6">
            <span className="text-gold text-xs tracking-[0.3em] uppercase font-medium">How It Works</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4" style={{ fontFamily: "var(--font-playfair)" }}>
            Simple &{" "}
            <span className="gold-text italic">Transparent</span>
          </h2>
          <p className="text-cream/50 max-w-xl mx-auto">
            A clear, six-step journey from first conversation to your dream home — no surprises, no delays.
          </p>
        </div>

        {/* Desktop timeline */}
        <div className="hidden md:block relative">
          {/* Center line */}
          <div className="absolute left-1/2 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-gold/40 to-transparent -translate-x-1/2" />

          <div className="space-y-12">
            {steps.map((step, i) => (
              <div
                key={step.num}
                className={`reveal flex items-center gap-8 ${i % 2 === 0 ? "flex-row" : "flex-row-reverse"}`}
              >
                {/* Card */}
                <div className="flex-1">
                  <div className={`glass-card p-8 max-w-sm ${i % 2 === 0 ? "ml-auto" : "mr-auto"}`}>
                    <div className="flex items-center gap-4 mb-4">
                      <div className="w-10 h-10 bg-gold/10 border border-gold/30 flex items-center justify-center">
                        <step.icon size={18} className="text-gold" />
                      </div>
                      <span className="gold-text text-3xl font-bold" style={{ fontFamily: "var(--font-playfair)" }}>{step.num}</span>
                    </div>
                    <h3 className="text-white font-bold text-xl mb-2" style={{ fontFamily: "var(--font-playfair)" }}>{step.title}</h3>
                    <p className="text-cream/50 text-sm leading-relaxed">{step.desc}</p>
                  </div>
                </div>

                {/* Center dot */}
                <div className="flex-shrink-0 w-4 h-4 bg-gold rounded-full border-2 border-charcoal ring-2 ring-gold/30 z-10" />

                {/* Spacer */}
                <div className="flex-1" />
              </div>
            ))}
          </div>
        </div>

        {/* Mobile timeline */}
        <div className="md:hidden relative pl-8">
          <div className="absolute left-3 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-gold/40 to-transparent" />

          <div className="space-y-8">
            {steps.map((step) => (
              <div key={step.num} className="reveal relative">
                <div className="absolute -left-[26px] top-4 w-4 h-4 bg-gold rounded-full border-2 border-charcoal ring-2 ring-gold/30" />
                <div className="glass-card p-6">
                  <div className="flex items-center gap-3 mb-3">
                    <step.icon size={16} className="text-gold" />
                    <span className="gold-text text-xl font-bold" style={{ fontFamily: "var(--font-playfair)" }}>{step.num}</span>
                  </div>
                  <h3 className="text-white font-bold text-lg mb-1" style={{ fontFamily: "var(--font-playfair)" }}>{step.title}</h3>
                  <p className="text-cream/50 text-sm leading-relaxed">{step.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
