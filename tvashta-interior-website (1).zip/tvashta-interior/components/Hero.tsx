"use client";
import { useEffect, useRef, useState } from "react";
import { ChevronDown } from "lucide-react";

const stats = [
  { value: 100, suffix: "+", label: "Projects Delivered" },
  { value: 5, suffix: "+", label: "Years Experience" },
  { value: 95, suffix: "%", label: "Client Satisfaction" },
  { value: 30, suffix: "+", label: "Design Experts" },
];

function CountUp({ target, suffix }: { target: number; suffix: string }) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const started = useRef(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !started.current) {
          started.current = true;
          let start = 0;
          const duration = 1800;
          const step = (target / duration) * 16;
          const interval = setInterval(() => {
            start += step;
            if (start >= target) {
              setCount(target);
              clearInterval(interval);
            } else {
              setCount(Math.floor(start));
            }
          }, 16);
        }
      },
      { threshold: 0.5 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [target]);

  return (
    <span ref={ref} className="gold-text text-3xl md:text-4xl font-bold" style={{ fontFamily: "var(--font-playfair)" }}>
      {count}{suffix}
    </span>
  );
}

export default function Hero() {
  const scrollToPortfolio = () => {
    document.querySelector("#portfolio")?.scrollIntoView({ behavior: "smooth" });
  };

  const scrollToContact = () => {
    document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="relative min-h-screen flex flex-col justify-center overflow-hidden">
      {/* Background image with overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1618219908412-a29a1bb7b86e?w=1920&q=90"
          alt="Luxury Interior"
          className="w-full h-full object-cover"
          style={{ pointerEvents: "none" }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/85 via-black/60 to-black/30" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30" />
      </div>

      {/* Gold accent line */}
      <div className="absolute top-0 left-0 right-0 h-[2px] bg-gradient-to-r from-transparent via-gold to-transparent z-10" />

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 pt-28 pb-20">
        <div className="max-w-3xl">
          {/* Eyebrow */}
          <div className="luxury-divider mb-8 max-w-xs">
            <span className="text-gold text-xs tracking-[0.3em] uppercase font-medium">Premium Interior Design</span>
          </div>

          {/* Headline */}
          <h1
            className="text-5xl md:text-7xl font-bold leading-tight mb-6 text-white"
            style={{ fontFamily: "var(--font-playfair)" }}
          >
            Designing Spaces That{" "}
            <span className="gold-text italic">Reflect</span>
            <br />
            Your Lifestyle
          </h1>

          <p className="text-cream/70 text-lg md:text-xl mb-10 max-w-xl leading-relaxed font-light">
            Premium interior design solutions for apartments, villas & commercial spaces across Bangalore. From concept to completion — we transform ideas into timeless experiences.
          </p>

          <div className="flex flex-wrap gap-4">
            <button
              onClick={scrollToPortfolio}
              className="allow-pointer bg-gold text-charcoal px-8 py-4 text-sm font-bold tracking-widest uppercase hover:bg-gold-light transition-colors"
            >
              Explore Portfolio
            </button>
            <button
              onClick={scrollToContact}
              className="allow-pointer border border-gold/60 text-gold px-8 py-4 text-sm font-bold tracking-widest uppercase hover:bg-gold/10 transition-colors"
            >
              Book Free Consultation
            </button>
          </div>
        </div>

        {/* Stats bar */}
        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-6">
          {stats.map((s) => (
            <div key={s.label} className="glass-card p-5 text-center">
              <CountUp target={s.value} suffix={s.suffix} />
              <p className="text-cream/50 text-xs tracking-widest uppercase mt-1 font-medium">{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <button
        onClick={scrollToPortfolio}
        className="allow-pointer absolute bottom-8 left-1/2 -translate-x-1/2 z-10 text-gold/60 hover:text-gold animate-bounce"
      >
        <ChevronDown size={28} />
      </button>
    </section>
  );
}
