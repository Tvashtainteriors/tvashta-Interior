"use client";
import { useState, useRef, useEffect } from "react";
import { Phone, Mail, MapPin, Send, MessageCircle } from "lucide-react";

export default function Contact() {
  const ref = useRef<HTMLDivElement>(null);
  const [form, setForm] = useState({ name: "", phone: "", email: "", service: "", message: "" });
  const [sent, setSent] = useState(false);

  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          e.target.querySelectorAll(".reveal").forEach((el, i) => {
            setTimeout(() => el.classList.add("visible"), i * 100);
          });
        }
      },
      { threshold: 0.1 }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSent(true);
  };

  const waLink = `https://wa.me/919876543210?text=Hi Tvashta! I'm interested in interior design for my home. My name is ${form.name || "..."}.`;

  return (
    <section id="contact" ref={ref} className="py-28 bg-[#0D0D0D] relative overflow-hidden">
      {/* Background accent */}
      <div className="absolute inset-0 pointer-events-none">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-gold/3 rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6">
        {/* CTA Banner */}
        <div className="reveal text-center mb-20">
          <div className="luxury-divider justify-center mb-6">
            <span className="text-gold text-xs tracking-[0.3em] uppercase font-medium">Let's Begin</span>
          </div>
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight" style={{ fontFamily: "var(--font-playfair)" }}>
            Ready To Design Your{" "}
            <span className="gold-text italic">Dream Home?</span>
          </h2>
          <p className="text-cream/50 max-w-xl mx-auto mb-10 text-lg">
            Schedule a free consultation and let our designers craft a space that's uniquely yours.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <button
              onClick={() => document.querySelector("form")?.scrollIntoView({ behavior: "smooth" })}
              className="allow-pointer bg-gold text-charcoal px-10 py-4 text-sm font-bold tracking-widest uppercase hover:bg-gold-light transition-colors"
            >
              Schedule Free Consultation
            </button>
            <a
              href={waLink}
              target="_blank"
              rel="noreferrer"
              className="allow-pointer flex items-center gap-2 border border-gold/50 text-gold px-10 py-4 text-sm font-bold tracking-widest uppercase hover:bg-gold/10 transition-colors"
            >
              <MessageCircle size={16} />
              WhatsApp Now
            </a>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Contact info */}
          <div>
            <h3 className="reveal text-2xl font-bold text-white mb-8" style={{ fontFamily: "var(--font-playfair)" }}>
              Get In Touch
            </h3>

            <div className="space-y-6">
              {[
                { icon: Phone, label: "Phone", value: "+91 98765 43210", href: "tel:+919876543210" },
                { icon: Mail, label: "Email", value: "hello@tvashta.in", href: "mailto:hello@tvashta.in" },
                { icon: MapPin, label: "Address", value: "Indiranagar, Bangalore — 560038", href: "#" },
              ].map((c) => (
                <div key={c.label} className="reveal flex items-start gap-4 glass-card p-5">
                  <div className="w-10 h-10 bg-gold/10 border border-gold/20 flex items-center justify-center flex-shrink-0">
                    <c.icon size={18} className="text-gold" />
                  </div>
                  <div>
                    <p className="text-gold text-xs tracking-widest uppercase font-medium mb-1">{c.label}</p>
                    <a href={c.href} className="allow-pointer text-cream/80 hover:text-white transition-colors">{c.value}</a>
                  </div>
                </div>
              ))}
            </div>

            {/* Business hours */}
            <div className="reveal glass-card p-6 mt-6">
              <p className="text-gold text-xs tracking-widest uppercase font-medium mb-4">Business Hours</p>
              <div className="space-y-2">
                {[
                  ["Monday – Saturday", "9:00 AM – 7:00 PM"],
                  ["Sunday", "By Appointment"],
                ].map(([day, time]) => (
                  <div key={day} className="flex justify-between text-sm">
                    <span className="text-cream/50">{day}</span>
                    <span className="text-cream/80">{time}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Form */}
          <div className="reveal">
            {sent ? (
              <div className="glass-card p-12 text-center h-full flex flex-col items-center justify-center">
                <div className="w-16 h-16 bg-gold/10 border border-gold/30 flex items-center justify-center mb-6">
                  <Send size={24} className="text-gold" />
                </div>
                <h3 className="text-2xl font-bold text-white mb-3" style={{ fontFamily: "var(--font-playfair)" }}>Message Received!</h3>
                <p className="text-cream/50">Our team will reach out within 24 hours. Thank you for choosing Tvashta Interior.</p>
                <button className="allow-pointer mt-8 text-gold text-sm border-b border-gold/30 hover:border-gold pb-1 transition-colors" onClick={() => setSent(false)}>
                  Send Another
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="glass-card p-8 space-y-5">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-gold text-xs tracking-widest uppercase font-medium block mb-2">Name *</label>
                    <input
                      type="text"
                      required
                      placeholder="Your Name"
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      className="allow-pointer w-full bg-white/5 border border-gold/20 text-cream placeholder-cream/20 px-4 py-3 text-sm focus:outline-none focus:border-gold/60 transition-colors"
                    />
                  </div>
                  <div>
                    <label className="text-gold text-xs tracking-widest uppercase font-medium block mb-2">Phone *</label>
                    <input
                      type="tel"
                      required
                      placeholder="+91 ..."
                      value={form.phone}
                      onChange={(e) => setForm({ ...form, phone: e.target.value })}
                      className="allow-pointer w-full bg-white/5 border border-gold/20 text-cream placeholder-cream/20 px-4 py-3 text-sm focus:outline-none focus:border-gold/60 transition-colors"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-gold text-xs tracking-widest uppercase font-medium block mb-2">Email</label>
                  <input
                    type="email"
                    placeholder="your@email.com"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    className="allow-pointer w-full bg-white/5 border border-gold/20 text-cream placeholder-cream/20 px-4 py-3 text-sm focus:outline-none focus:border-gold/60 transition-colors"
                  />
                </div>

                <div>
                  <label className="text-gold text-xs tracking-widest uppercase font-medium block mb-2">Service Interested In</label>
                  <select
                    value={form.service}
                    onChange={(e) => setForm({ ...form, service: e.target.value })}
                    className="allow-pointer w-full bg-[#1A1A1A] border border-gold/20 text-cream/70 px-4 py-3 text-sm focus:outline-none focus:border-gold/60 transition-colors"
                  >
                    <option value="">Select a service...</option>
                    <option>Complete Home Interior</option>
                    <option>Modular Kitchen</option>
                    <option>Bedroom Design</option>
                    <option>TV Unit & Living Room</option>
                    <option>False Ceiling</option>
                    <option>Commercial Interior</option>
                    <option>Other</option>
                  </select>
                </div>

                <div>
                  <label className="text-gold text-xs tracking-widest uppercase font-medium block mb-2">Message</label>
                  <textarea
                    rows={4}
                    placeholder="Tell us about your project, location, and budget..."
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    className="allow-pointer w-full bg-white/5 border border-gold/20 text-cream placeholder-cream/20 px-4 py-3 text-sm focus:outline-none focus:border-gold/60 transition-colors resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="allow-pointer w-full bg-gold text-charcoal py-4 text-sm font-bold tracking-widest uppercase hover:bg-gold-light transition-colors flex items-center justify-center gap-2"
                >
                  <Send size={15} />
                  Send Enquiry
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
