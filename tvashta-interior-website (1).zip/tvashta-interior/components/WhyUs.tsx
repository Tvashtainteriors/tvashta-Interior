"use client";
import { useEffect, useRef } from "react";
import { DollarSign, Box, Gem, Clock, User, LifeBuoy, ShieldCheck, Wrench } from "lucide-react";

const features = [
  { icon: DollarSign, title: "Transparent Pricing", desc: "Detailed quotations with no hidden charges. What you see is what you pay." },
  { icon: Box, title: "3D Design Visualization", desc: "Photorealistic 3D renders so you can experience your space before execution." },
  { icon: Gem, title: "Premium Materials", desc: "We source only from certified, premium material suppliers for lasting quality." },
  { icon: Clock, title: "On-Time Delivery", desc: "We commit to timelines and honor them. No delays, no excuses." },
  { icon: User, title: "Dedicated Project Manager", desc: "A single point of contact who oversees every detail of your project." },
  { icon: LifeBuoy, title: "Lifetime Design Support", desc: "Post-project support for any design queries, changes, or additions." },
  { icon: ShieldCheck, title: "Warranty Assistance", desc: "We help you navigate manufacturer warranties on all hardware and materials." },
  { icon: Wrench, title: "Custom Furniture Solutions", desc: "Bespoke furniture crafted to fit your exact space and taste." },
];

export default function WhyUs() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          e.target.querySelectorAll(".reveal").forEach((el, i) => {
            setTimeout(() => el.classList.add("visible"), i * 80);
          });
        }
      },
      { threshold: 0.1 }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);

  return (
    <section ref={ref} className="py-28 bg-[#111111]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16 reveal">
          <div className="luxury-divider justify-center mb-6">
            <span className="text-gold text-xs tracking-[0.3em] uppercase font-medium">Our Promise</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4" style={{ fontFamily: "var(--font-playfair)" }}>
            Why Clients <span className="gold-text italic">Choose Us</span>
          </h2>
          <p className="text-cream/50 max-w-xl mx-auto">Eight commitments that define the Tvashta experience.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {features.map((f, i) => (
            <div
              key={f.title}
              className="reveal glass-card p-7 hover:border-gold/30 transition-colors group"
            >
              <div className="w-12 h-12 bg-gold/10 border border-gold/20 flex items-center justify-center mb-5 group-hover:bg-gold/20 transition-colors">
                <f.icon size={20} className="text-gold" />
              </div>
              <h3 className="text-white font-bold text-base mb-2" style={{ fontFamily: "var(--font-playfair)" }}>{f.title}</h3>
              <p className="text-cream/40 text-sm leading-relaxed">{f.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
