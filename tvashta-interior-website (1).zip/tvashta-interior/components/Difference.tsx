"use client";
import { useEffect, useRef } from "react";
import { Clock, Palette, DollarSign, Grid3x3, Star, Headphones } from "lucide-react";

const rows = [
  { icon: Clock, feature: "Timely Deliveries", market: "Delays Common", tvashta: "On-Time Guarantee" },
  { icon: Palette, feature: "Customization", market: "Limited Options", tvashta: "Fully Personalized" },
  { icon: DollarSign, feature: "Cost Efficiency", market: "Hidden Costs", tvashta: "Transparent Pricing" },
  { icon: Grid3x3, feature: "Product Variety", market: "Standard Catalog", tvashta: "Endless Choices" },
  { icon: Star, feature: "Quality Assurance", market: "Inconsistent", tvashta: "Premium Checks" },
  { icon: Headphones, feature: "Customer Support", market: "Unresponsive", tvashta: "Dedicated Support" },
];

export default function Difference() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const obs = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          e.target.querySelectorAll(".reveal").forEach((el, i) => {
            setTimeout(() => el.classList.add("visible"), i * 80);
          });
        }
      },
      { threshold: 0.1 }
    );
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);

  return (
    <section id="difference" ref={ref} className="py-28 bg-[#0D0D0D]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16 reveal">
          <div className="luxury-divider justify-center mb-6">
            <span className="text-gold text-xs tracking-[0.3em] uppercase font-medium">Our Edge</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4" style={{ fontFamily: "var(--font-playfair)" }}>
            The <span className="gold-text italic">Tvashta</span> Difference
          </h2>
          <p className="text-cream/50 max-w-xl mx-auto">Why discerning homeowners choose Tvashta for their most important spaces.</p>
        </div>

        {/* Table */}
        <div className="reveal max-w-4xl mx-auto">
          {/* Header */}
          <div className="grid grid-cols-3 mb-2">
            <div className="text-center py-3 px-4 bg-white/5 border border-white/10">
              <p className="text-cream/40 text-xs tracking-widest uppercase font-medium">Market Standard</p>
            </div>
            <div className="text-center py-3 px-4 bg-gold/10 border border-gold/30">
              <p className="text-gold text-xs tracking-widest uppercase font-semibold">Feature</p>
            </div>
            <div className="text-center py-3 px-4 bg-gold text-charcoal">
              <p className="text-xs tracking-widest uppercase font-bold">Tvashta Advantage</p>
            </div>
          </div>

          {rows.map((row, i) => (
            <div
              key={row.feature}
              className="comparison-row grid grid-cols-3 border-b border-white/5 transition-colors"
              style={{ animationDelay: `${i * 100}ms` }}
            >
              <div className="py-5 px-6 flex items-center justify-center text-center">
                <span className="text-cream/30 text-sm">{row.market}</span>
              </div>
              <div className="py-5 px-6 flex items-center justify-center text-center bg-gold/5 border-x border-gold/10">
                <div className="flex flex-col items-center gap-2">
                  <row.icon size={18} className="text-gold" />
                  <span className="text-cream/80 text-sm font-medium">{row.feature}</span>
                </div>
              </div>
              <div className="py-5 px-6 flex items-center justify-center text-center">
                <span className="text-gold font-semibold text-sm">{row.tvashta}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="reveal text-center mt-16">
          <button
            onClick={() => document.querySelector("#contact")?.scrollIntoView({ behavior: "smooth" })}
            className="allow-pointer border border-gold text-gold px-10 py-4 text-sm font-bold tracking-widest uppercase hover:bg-gold hover:text-charcoal transition-all duration-300"
          >
            Experience the Difference
          </button>
        </div>
      </div>
    </section>
  );
}
