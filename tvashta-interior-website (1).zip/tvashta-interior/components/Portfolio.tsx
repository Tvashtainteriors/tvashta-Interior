"use client";
import { useState, useEffect, useRef } from "react";
import { Search, X, ZoomIn, MapPin, Ruler, Clock, DollarSign } from "lucide-react";
import { projects, categories, subcategories, type Project } from "@/data/portfolio";

export default function Portfolio() {
  const [activeCategory, setActiveCategory] = useState("All");
  const [activeSubcat, setActiveSubcat] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState<Project | null>(null);
  const [visible, setVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(([e]) => { if (e.isIntersecting) setVisible(true); }, { threshold: 0.1 });
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  const filtered = projects.filter((p) => {
    const matchCat = activeCategory === "All" || p.category === activeCategory;
    const matchSubcat = !activeSubcat || p.subcategory === activeSubcat;
    const matchSearch = !search || p.title.toLowerCase().includes(search.toLowerCase()) || p.subcategory.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSubcat && matchSearch;
  });

  const handleCategory = (cat: string) => {
    setActiveCategory(cat);
    setActiveSubcat(null);
  };

  return (
    <section id="portfolio" ref={sectionRef} className="py-28 bg-[#111111]">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="luxury-divider justify-center mb-6">
            <span className="text-gold text-xs tracking-[0.3em] uppercase font-medium">Our Work</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4" style={{ fontFamily: "var(--font-playfair)" }}>
            Portfolio <span className="gold-text italic">Gallery</span>
          </h2>
          <p className="text-cream/50 max-w-xl mx-auto">Explore our curated collection of premium interior transformations across Bangalore.</p>
        </div>

        {/* Search */}
        <div className="relative max-w-md mx-auto mb-10">
          <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-cream/30" />
          <input
            type="text"
            placeholder="Search designs…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="allow-pointer w-full bg-white/5 border border-gold/20 text-cream placeholder-cream/30 pl-10 pr-4 py-3 text-sm focus:outline-none focus:border-gold/60 transition-colors"
          />
          {search && (
            <button className="allow-pointer absolute right-4 top-1/2 -translate-y-1/2 text-cream/30 hover:text-cream" onClick={() => setSearch("")}>
              <X size={14} />
            </button>
          )}
        </div>

        {/* Category filters */}
        <div className="flex flex-wrap justify-center gap-2 mb-6">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => handleCategory(cat)}
              className={`allow-pointer filter-pill ${activeCategory === cat ? "active" : ""}`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Sub-category filters */}
        {activeCategory !== "All" && subcategories[activeCategory] && (
          <div className="flex flex-wrap justify-center gap-2 mb-10">
            {subcategories[activeCategory].map((sub) => (
              <button
                key={sub}
                onClick={() => setActiveSubcat(activeSubcat === sub ? null : sub)}
                className={`allow-pointer filter-pill text-xs ${activeSubcat === sub ? "active" : ""}`}
              >
                {sub}
              </button>
            ))}
          </div>
        )}

        {/* Grid */}
        <div className="columns-1 sm:columns-2 lg:columns-3 gap-4 space-y-4">
          {filtered.map((project, i) => (
            <div
              key={project.id}
              className={`gallery-item break-inside-avoid cursor-pointer transition-all duration-700 ${visible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}
              style={{ transitionDelay: `${(i % 6) * 80}ms` }}
              onClick={() => { setSelected(project); }}
            >
              <div className="relative overflow-hidden" style={{ background: project.color }}>
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full object-cover"
                  loading="lazy"
                  style={{ pointerEvents: "none" }}
                />
                <div className="gallery-overlay" />
                <div className="absolute inset-0 flex flex-col justify-end p-5 opacity-0 group-hover:opacity-100 transition-opacity">
                  <div className="pointer-events-none" />
                </div>
                {/* Always visible on hover */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity duration-300">
                  <div className="bg-gold/90 rounded-full p-3">
                    <ZoomIn size={20} className="text-charcoal" />
                  </div>
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-full hover:translate-y-0 transition-transform duration-300 bg-gradient-to-t from-black/90 to-transparent">
                  <p className="text-white font-semibold text-sm" style={{ fontFamily: "var(--font-playfair)" }}>{project.title}</p>
                  <p className="text-gold text-xs mt-1">{project.subcategory}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-20 text-cream/30">
            <p className="text-lg">No designs found for your search.</p>
          </div>
        )}
      </div>

      {/* Project Detail Modal */}
      {selected && (
        <div
          className="allow-pointer fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4 md:p-8"
          onClick={() => setSelected(null)}
        >
          <div
            className="allow-pointer relative max-w-4xl w-full max-h-[90vh] overflow-y-auto glass-card"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              className="allow-pointer absolute top-4 right-4 z-10 text-cream/60 hover:text-gold bg-black/50 rounded-full p-2"
              onClick={() => setSelected(null)}
            >
              <X size={18} />
            </button>

            <div className="grid md:grid-cols-2">
              {/* Image */}
              <div className="relative aspect-[4/3] md:aspect-auto">
                <img src={selected.image} alt={selected.title} className="w-full h-full object-cover" style={{ pointerEvents: "none" }} />
              </div>

              {/* Details */}
              <div className="p-8">
                <span className="text-gold text-xs tracking-widest uppercase font-medium">{selected.category}</span>
                <h3 className="text-2xl font-bold text-white mt-2 mb-1" style={{ fontFamily: "var(--font-playfair)" }}>{selected.title}</h3>
                <p className="text-gold/80 text-sm mb-4">{selected.subcategory}</p>

                <div className="grid grid-cols-2 gap-3 mb-6">
                  {[
                    { icon: MapPin, label: selected.location },
                    { icon: Ruler, label: selected.area },
                    { icon: DollarSign, label: selected.budget },
                    { icon: Clock, label: selected.completionTime },
                  ].map((item) => (
                    <div key={item.label} className="flex items-start gap-2 text-cream/60 text-xs">
                      <item.icon size={13} className="text-gold mt-0.5 flex-shrink-0" />
                      <span>{item.label}</span>
                    </div>
                  ))}
                </div>

                <div className="border-t border-gold/10 pt-5 mb-5">
                  <p className="text-cream/70 text-sm leading-relaxed">{selected.description}</p>
                </div>

                <div>
                  <p className="text-gold text-xs tracking-widest uppercase font-medium mb-3">Materials Used</p>
                  <div className="flex flex-wrap gap-2">
                    {selected.materials.map((m) => (
                      <span key={m} className="text-xs px-3 py-1 border border-gold/20 text-cream/60">{m}</span>
                    ))}
                  </div>
                </div>

                <div className="mt-8">
                  <a
                    href="https://wa.me/919876543210"
                    target="_blank"
                    rel="noreferrer"
                    className="allow-pointer block w-full text-center bg-gold text-charcoal py-3 text-sm font-bold tracking-widest uppercase hover:bg-gold-light transition-colors"
                  >
                    Enquire About This Design
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}
