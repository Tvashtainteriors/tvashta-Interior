"use client";
import { useState, useEffect } from "react";
import Image from "next/image";
import { Menu, X, Phone } from "lucide-react";

const navLinks = [
  { label: "About", href: "#about" },
  { label: "Portfolio", href: "#portfolio" },
  { label: "Why Us", href: "#difference" },
  { label: "Process", href: "#process" },
  { label: "Testimonials", href: "#testimonials" },
  { label: "Contact", href: "#contact" },
];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleNav = (href: string) => {
    setOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled ? "nav-blur border-b border-gold/10 py-3" : "py-5"
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-3 allow-pointer cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}>
          <div className="relative w-24 h-10">
            <Image src="/logo.png" alt="Tvashta Interior" fill className="object-contain" style={{ pointerEvents: "none" }} />
          </div>
        </div>

        {/* Desktop nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((l) => (
            <button
              key={l.label}
              onClick={() => handleNav(l.href)}
              className="allow-pointer text-cream/70 hover:text-gold transition-colors text-sm font-medium tracking-wide"
            >
              {l.label}
            </button>
          ))}
          <a
            href="tel:+919876543210"
            className="allow-pointer flex items-center gap-2 bg-gold text-charcoal px-4 py-2 text-sm font-semibold tracking-wide hover:bg-gold-light transition-colors"
          >
            <Phone size={14} />
            Call Now
          </a>
        </div>

        {/* Mobile menu toggle */}
        <button
          className="allow-pointer md:hidden text-cream"
          onClick={() => setOpen(!open)}
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile drawer */}
      {open && (
        <div className="md:hidden nav-blur border-t border-gold/10 px-6 py-6 flex flex-col gap-4">
          {navLinks.map((l) => (
            <button
              key={l.label}
              onClick={() => handleNav(l.href)}
              className="allow-pointer text-left text-cream/80 hover:text-gold text-base font-medium"
            >
              {l.label}
            </button>
          ))}
          <a href="tel:+919876543210" className="allow-pointer mt-2 flex items-center gap-2 bg-gold text-charcoal px-4 py-3 text-sm font-bold w-fit">
            <Phone size={14} /> Call Now
          </a>
        </div>
      )}
    </nav>
  );
}
