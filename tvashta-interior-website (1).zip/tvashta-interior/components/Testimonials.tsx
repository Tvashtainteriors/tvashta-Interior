"use client";
import { useEffect, useRef, useState } from "react";
import { Star, ChevronLeft, ChevronRight, Quote } from "lucide-react";
import { testimonials } from "@/data/portfolio";

export default function Testimonials() {
  const [active, setActive] = useState(0);
  const timerRef = useRef<ReturnType<typeof setInterval> | undefined>(undefined);

  const startTimer = () => {
    clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setActive((a) => (a + 1) % testimonials.length);
    }, 5000);
  };

  useEffect(() => {
    startTimer();
    return () => clearInterval(timerRef.current);
  }, []);

  const go = (dir: number) => {
    setActive((a) => (a + dir + testimonials.length) % testimonials.length);
    startTimer();
  };

  const t = testimonials[active];

  return (
    <section id="testimonials" className="py-28 bg-[#0D0D0D]">
      <div className="max-w-5xl mx-auto px-6">
        <div className="text-center mb-16">
          <div className="luxury-divider justify-center mb-6">
            <span className="text-gold text-xs tracking-[0.3em] uppercase font-medium">Client Stories</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white" style={{ fontFamily: "var(--font-playfair)" }}>
            What Our <span className="gold-text italic">Clients Say</span>
          </h2>
        </div>

        <div className="relative">
          {/* Big quote */}
          <Quote size={80} className="absolute -top-6 -left-4 text-gold/5" />

          {/* Card */}
          <div key={active} className="glass-card p-10 md:p-16 text-center">
            {/* Stars */}
            <div className="stars flex justify-center gap-1 mb-8">
              {Array(t.rating).fill(0).map((_, i) => (
                <Star key={i} size={18} fill="currentColor" />
              ))}
            </div>

            <blockquote
              className="text-cream/80 text-xl md:text-2xl leading-relaxed italic mb-10 max-w-3xl mx-auto"
              style={{ fontFamily: "var(--font-cormorant)" }}
            >
              "{t.review}"
            </blockquote>

            {/* Avatar */}
            <div className="flex flex-col items-center gap-3">
              <div
                className="w-14 h-14 rounded-full flex items-center justify-center text-white font-bold text-lg"
                style={{ background: t.color }}
              >
                {t.initials}
              </div>
              <div>
                <p className="text-white font-semibold" style={{ fontFamily: "var(--font-playfair)" }}>{t.name}</p>
                <p className="text-gold text-xs tracking-widest uppercase mt-0.5">{t.project}</p>
              </div>
            </div>
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-center gap-6 mt-8">
            <button
              onClick={() => go(-1)}
              className="allow-pointer w-10 h-10 border border-gold/30 text-gold/60 hover:border-gold hover:text-gold flex items-center justify-center transition-colors"
            >
              <ChevronLeft size={18} />
            </button>

            {/* Dots */}
            <div className="flex gap-2">
              {testimonials.map((_, i) => (
                <button
                  key={i}
                  onClick={() => { setActive(i); startTimer(); }}
                  className={`allow-pointer w-2 h-2 rounded-full transition-all duration-300 ${
                    i === active ? "bg-gold w-6" : "bg-gold/20"
                  }`}
                />
              ))}
            </div>

            <button
              onClick={() => go(1)}
              className="allow-pointer w-10 h-10 border border-gold/30 text-gold/60 hover:border-gold hover:text-gold flex items-center justify-center transition-colors"
            >
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
